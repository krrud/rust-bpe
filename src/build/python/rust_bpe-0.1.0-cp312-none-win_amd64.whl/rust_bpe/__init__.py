from .rust_bpe import *

__doc__ = rust_bpe.__doc__
if hasattr(rust_bpe, "__all__"):
    __all__ = rust_bpe.__all__